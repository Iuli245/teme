import java.math.BigDecimal;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        PortofoliuGenerics<Instrument> portofoliu = new PortofoliuGenerics<>();

        Instrument instrument1 = new Instrument("BTC");
        instrument1.adaugaOperatiune(new Operatiune(TipOperatiune.CUMPARARE, LocalDate.of(2023, 3, 1), new BigDecimal("30000.50"), 2));
        instrument1.adaugaOperatiune(new Operatiune(TipOperatiune.VANZARE, LocalDate.of(2024, 2, 20), new BigDecimal("60000.00"), 1));

        Actiune actiune1 = new Actiune("AAPL");
        actiune1.adaugaOperatiune(new Operatiune(TipOperatiune.CUMPARARE, LocalDate.of(2022, 5, 10), new BigDecimal("150.00"), 10));

        portofoliu.adaugaInstrument("BTC", instrument1);
        portofoliu.adaugaInstrument("AAPL", actiune1);

        System.out.println("Continutul portofoliului:");
        portofoliu.afiseazaPortofoliu();

        System.out.println("\nValoare totala: " + portofoliu.valoarePortofoliu());

        System.out.println("\nData primei operatiuni pentru fiecare instrument:");
        for (var entry : portofoliu.getPortofoliu().entrySet()) {
            var operatiuni = entry.getValue().getOperatiuni();
            if (!operatiuni.isEmpty()) {
                LocalDate dataMin = operatiuni.stream().map(Operatiune::getData).min(LocalDate::compareTo).orElse(null);
                System.out.println(entry.getKey() + " -> " + dataMin);
            }
        }
    }
}