import java.util.ArrayList;
import java.util.List;

public class Instrument implements Evaluabil {
    private String symbol;
    private List<Operatiune> operatiuni;

    public Instrument() {
        this.symbol = "";
        this.operatiuni = new ArrayList<>();
    }

    public Instrument(String symbol) {
        this.symbol = symbol;
        this.operatiuni = new ArrayList<>();
    }

    public String getSymbol() { return symbol; }
    public List<Operatiune> getOperatiuni() { return operatiuni; }
    public void adaugaOperatiune(Operatiune op) { operatiuni.add(op); }

    @Override
    public double valoare() {
        return operatiuni.stream()
                .mapToDouble(op -> op.getPret().doubleValue() * op.getCantitate() * op.getTip().directie())
                .sum();
    }
}