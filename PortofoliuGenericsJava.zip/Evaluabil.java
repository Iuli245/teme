public interface Evaluabil {
    default double valoare() {
        return 0.0;
    }
}