public class Actiune extends Instrument {
    public Actiune() { super(); }
    public Actiune(String simbol) { super(simbol); }
}