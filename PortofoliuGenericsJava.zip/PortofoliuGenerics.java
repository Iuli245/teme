import java.util.HashMap;
import java.util.Map;

public class PortofoliuGenerics<T extends Evaluabil> {
    private Map<String, T> portofoliu;

    public PortofoliuGenerics() {
        this.portofoliu = new HashMap<>();
    }

    public PortofoliuGenerics(Map<String, T> portofoliu) {
        this.portofoliu = portofoliu;
    }

    public Map<String, T> getPortofoliu() { return portofoliu; }
    public void setPortofoliu(Map<String, T> portofoliu) { this.portofoliu = portofoliu; }
    public void adaugaInstrument(String simbol, T instrument) { portofoliu.put(simbol, instrument); }
    public T getInstrument(String simbol) { return portofoliu.get(simbol); }
    public void afiseazaPortofoliu() {
        for (Map.Entry<String, T> entry : portofoliu.entrySet()) {
            System.out.println("Simbol: " + entry.getKey() + ", Valoare: " + entry.getValue().valoare());
        }
    }
    public double valoarePortofoliu() {
        return portofoliu.values().stream().mapToDouble(T::valoare).sum();
    }
}