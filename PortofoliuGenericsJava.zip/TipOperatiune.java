public enum TipOperatiune {
    CUMPARARE,
    VANZARE;

    public int directie() {
        return this == CUMPARARE ? 1 : -1;
    }
}