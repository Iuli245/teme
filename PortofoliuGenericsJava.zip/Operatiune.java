import java.math.BigDecimal;
import java.time.LocalDate;

public class Operatiune {
    private final TipOperatiune tip;
    private final LocalDate data;
    private final BigDecimal pret;
    private final int cantitate;

    public Operatiune(TipOperatiune tip, LocalDate data, BigDecimal pret, int cantitate) {
        this.tip = tip;
        this.data = data;
        this.pret = pret;
        this.cantitate = cantitate;
    }

    public TipOperatiune getTip() { return tip; }
    public LocalDate getData() { return data; }
    public BigDecimal getPret() { return pret; }
    public int getCantitate() { return cantitate; }
}